def require(clasds):
    from importlib import import_module
    return import_module('applet.' + clasds)
def fix_filepath(path):
    return 'applet/' + path
def nt_filepath(path):
    return 'applet\\' + path